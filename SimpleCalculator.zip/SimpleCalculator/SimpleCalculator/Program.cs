﻿using System;

namespace SimpleCalculator
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter first number");
            var number1 = int.Parse(Console.ReadLine());
            
            Console.WriteLine("Enter second number");
            var number2 = int.Parse(Console.ReadLine());
            
            Console.WriteLine("Enter operation");
            var operation = Console.ReadLine().ToUpperInvariant();

            try
            {
                var calculator = new Calculator();
                var result = calculator.Calculate(number1, number2, operation);

                Console.WriteLine(result);
            }
            catch (ArgumentNullException)
            {
                Console.WriteLine("ARgument Exception. Your argument was null.");
            }
            catch (ArgumentException e) when (e.Message == "Do not divide by zero ever ever ever!")
            {
                Console.WriteLine("ARgument Exception");
            }
            catch (ArgumentException e)
            {
                Console.WriteLine("ARgument Exception");
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
            finally
            {
                Console.WriteLine("End of Operation");
            }

            ;


        }
    }
}