using System;

namespace SimpleCalculator
{
    public class Calculator
    {
        // public Calculator(IPersonService personService)
        // {
        //     _personService = personService ?? throw new ArgumentNullException()
        // }
        public int Calculate(int number1, int number2, string operation)
        {
            var nonNullOperartion = operation ?? throw new ArgumentNullException(nameof(operation));
            
            if (nonNullOperartion == "/")
            {
                try
                {
                    return Divide(number1, number2);
                }
                catch (DivideByZeroException e)
                {
                    Console.WriteLine("Do not divide by zero ever ever ever!");
                    throw new ArgumentException("Do not divide by zero ever ever ever!", e);
                }
            }

            throw new ArgumentException(nameof(operation));
        }

        static int Divide(int number1, int number2)
        {
            return number1 / number2;
        }
    }
}